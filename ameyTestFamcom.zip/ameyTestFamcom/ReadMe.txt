1 Firstly install all necessary modules using command npm install
2.Create a database with name test and in case you want to change the database name then go in config file and change the database name .
3.Import sql file which is in Database folder.
4.After then run command node app.js.
This project will run on this http://localhost:3016/

5.Forget functionality will not work because I put dummy email id if you wants to check then go on follwing path

controller >> authuser.controller 
In  authuser.controller page go on the 96 Line Here you have to set your email id and password 
And then login with same gmail id  which you set in this project and 
Hit this url https://myaccount.google.com/lesssecureapps
And then Allow less secure apps: ON 

OK

Now your project is ready if you have any query then please call me on that number 8319780015 any time

Ok sir bye Have a nice day

Thank You