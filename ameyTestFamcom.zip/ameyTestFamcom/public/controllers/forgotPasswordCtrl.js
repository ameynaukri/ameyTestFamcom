myApp.controller("forgotPasswordCtrl", function($scope,$http,$location,localStorageService,$rootScope,$window){
    $scope.error = "";
    $scope.chgPassword = function(formData){
        if (/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test($scope.formData.username)){
            $http.post($rootScope.serviceURL+"forgotpassword", $scope.formData).then(function(response){
                if(response.data.StatusCode == 400){
                    swal({
                        title: "Error!",
                        text: "This username is not exists!",
                        icon: "error",
                    });
                }else{
                    swal({
                        title: "Success!",
                        text: "Your new password is send on your email id!",
                        icon: "success",
                    });

                }
            }).catch(function(error){
                console.log(error);
            });
            $location.path("/");
        }else{
            $scope.error = "Invalid email id";
        }
    }
});
    
