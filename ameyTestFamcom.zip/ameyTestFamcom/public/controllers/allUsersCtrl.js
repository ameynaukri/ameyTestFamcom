myApp.controller("allUsersCtrl", function($scope,$http,$location,localStorageService,$rootScope){
    if(window.localStorage['storageName'] == "" || !window.localStorage['storageName']){
        $location.path("/");
    }else{
        $scope.uData = window.localStorage['storageName'];
        var userData = JSON.parse($scope.uData);
        $scope.username = userData.result.username; 
        $scope.id = userData.result.id; 
        $scope.token = userData.result.token;
        //$location.path("/allUsers");
    }
    $scope.allcustomer = function(){
        $scope.authData= {
            id : $scope.id,
            token : $scope.token
        }
       // $http.post($rootScope.serviceURL+"editReg", data).then(function(response){
        $http.post($rootScope.serviceURL+"allcustomer", $scope.authData).then(function(response) {
            $scope.allUser = response.data.result;
        });
        $scope.edit= {
            id : "",
            contact_no : "",
            full_name : ""
        }
    }    
    $scope.allcustomer();
    $scope.detail = function(data){
        $scope.edit= {
            id : data.id,
            contact_no : data.contact_no,
            full_name : data.full_name
        }
    }
    $scope.cancel = function(){
        $scope.edit= {
            id : "",
            contact_no : "",
            full_name : ""
        }
        $scope.error =""
    }
    $scope.error =""
    $scope.save = function(data){
        console.log("data ",data);
        if(data.full_name && data.contact_no){
            data.user_id = data.id;
            data.id = $scope.id;
            data.token = $scope.token;
            $http.post($rootScope.serviceURL+"editReg", data).then(function(response){
                var data = response.data;
                swal({
                  title: "Success!",
                  text: "Record edited successfully!",
                  icon: "success",
                });
                $scope.error =""
                //$location.path("/all-users")
                $scope.allcustomer();
            }).catch(function(error){
                console.log(error);
            });
        }else{
            $scope.error ="Please enter the correct input."
        }
    }
    $scope.delete = function(data){
        swal({
            title: 'Are you sure?',
            text: "you wants to delete this record.",
            type: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Yes, delete it!'
        }).then(function (isConfirm) {
            if(isConfirm){
                $scope.edit = data;
                var id = $scope.edit.id
                console.log($scope.edit);
                $scope.edit_id = "";
                $http.delete($rootScope.serviceURL+"deleteReord?user_id="+id+"&id="+$scope.id+"&token="+$scope.token)
                .then(function(response){
                var data = response.data;
                    if(data.Status == "Success"){
                        swal({
                            title: 'Deleted!',
                            text: 'Your record has been deleted.',
                            type: 'success',
                            confirmButtonText: "Ok",
                        }).then(function (isConfirm) {
                            //window.location.reload();
                        });
                    } else {
                        swal({   
                            title: "Error",   
                            text: "Error in Deleting record.",   
                            type: "error",   
                            confirmButtonText: "Ok",
                        }).then(function (isConfirm) {
                            //window.location.reload();
                        });
                    }
                    $scope.allcustomer();
                }).catch(function(error){
                    console.log(error);
                });
            } 
            else{
                $scope.allcustomer();
            }   
        })
    }
});