myApp.controller("loginCtrl", function($scope,$http,$location,localStorageService,$rootScope){
    if(window.localStorage['storageName'] == "" || !window.localStorage['storageName']){
        $location.path("/");
    }else{
        $scope.uData = window.localStorage['storageName'];
        var userData = JSON.parse($scope.uData);
        $scope.username = userData.result.username; 
        $location.path("/all-users");
    }
    $scope.signInUser = function(isValid){
        if(isValid){
            $http.post($rootScope.serviceURL+"Login", $scope.formData)
            .then(function(response){
                var data = response.data;
                console.log(data);
                if(data.StatusCode == 200){
                    window.localStorage['storageName'] = angular.toJson(data);
                    $scope.uData = window.localStorage['storageName'];
                    var userData = JSON.parse($scope.uData);
                    $scope.username = userData.result.username; 
                    swal({   
                        title: "Success",   
                        text: "Welcome"+$scope.username,   
                        type: "success",   
                        confirmButtonText: "Ok"
                    });
                    $location.path("all-users"); 
                } else {
                    swal({   
                        title: "Error",   
                        text: "Invalid email or password.",   
                        type: "error",   
                        confirmButtonText: "Ok"
                    });
                }
            }).catch(function(error){
                console.log(error);
            });
        } else {
            $scope.submitted = true;
        }
    }

});