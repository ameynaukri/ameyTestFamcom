myApp.controller("AddRegCtrl", function($scope,$http,$location,localStorageService,$rootScope){
    if(window.localStorage['storageName'] == "" || !window.localStorage['storageName']){
        $location.path("/");
    }else{
        $scope.uData = window.localStorage['storageName'];
        var userData = JSON.parse($scope.uData);
        $scope.username = userData.result.username; 
        $scope.id = userData.result.id; 
        $scope.token = userData.result.token; 
        //$location.path("/addReg");
    } 
    
    $scope.formData= {
        username : " ",
        full_name : " ",
        contact_no : " ",
        id : $scope.id,
        token : $scope.token,
        
    }
    
    $scope.formValid = true; 
    $scope.chkpassword = function(formData){
        console.log("ppppppppppppp",formData);
        $scope.password = formData.password;
        $scope.confirmpassword = formData.password_c;
        console.log("pas",formData.password);
        console.log("password_c",formData.password_c);
        if($scope.password == $scope.confirmpassword){
            $scope.formValid = false;
        }else{
            $scope.formValid = true;
        }

    }
    
    $scope.chkUsername = function(formData){
        if (/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(formData.username)){
            $http.post($rootScope.serviceURL+"chkuser", formData).then(function(response){
                if(response.data.statusCode == 400){
                    swal({
                        title: "Error!",
                        text: "This username is already exists!",
                        icon: "error",
                    });
                }
            }).catch(function(error){
                console.log(error);
            });
        }
    }
    $scope.error =""
    $scope.regUser = function(isValid){
        if(isValid){
            if($scope.formData.password == $scope.formData.password_c){
                $http.post($rootScope.serviceURL+"chkuser", $scope.formData).then(function(response){
                    if(response.data.statusCode == 400){
                        swal({
                            title: "Error!",
                            text: "This username is already exists!",
                            icon: "error",
                        });
                    }else{
                        //$scope.formData.push($scope.auth);
                        console.log("$scope.formData ",$scope.formData);
                        $http.post($rootScope.serviceURL+"addReg", $scope.formData).then(function(response){
                            var data = response.data;
                            swal({
                              title: "Success!",
                              text: "Add record successfully!",
                              icon: "success",
                            });
                            $location.path("/all-users");
                        }).catch(function(error){
                            console.log(error);
                        });
                    }
                }).catch(function(error){
                    console.log(error);
                });
            }else{
                $scope.error ="Password and confirm password should be same."
            }
        } else {
            $scope.error =""
            $scope.submitted = true;
        }
    }
    
});