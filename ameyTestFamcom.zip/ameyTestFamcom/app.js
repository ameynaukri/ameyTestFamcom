var express        = require('express'),
	expressHbs     = require('express-handlebars'),
	config         = require('./config'),
	app 		   = express(),
	bodyParser     = require('body-parser'),
	methodOverride = require('method-override'),
  errorHandler   = require('errorhandler'),
  cookieParser   = require('cookie-parser'),
  session        = require('express-session'),
  multiLogger    = require('./services/logger.service'),
  passportAuth = require('./authenticate');
  routes         = require('./routes'),
  path 		   = require('path'),
  server = require('http').createServer(app);


app.set('port', config.server.internalPort);
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'hbs');

app
  .use(bodyParser())
  .use(express.static(path.join(__dirname, 'public')))
  .use(cookieParser())
  .use(session({secret: config.session.secret
    , resave:false
    , saveUninitialized:false}))
  .use(passportAuth.initialize())
  .use(passportAuth.session())
  .use(routes.router)
  .use(function (req, res) {
    res.status(404).render('404', {title: 'Not Found :('});
  });
app.use(require('less-middleware')({
    src: __dirname + '/public'
}));
app.use(express.static(path.join(__dirname, 'public')));
// catch 404 and forward to error handler


// error handlers
app.use(function (err, req, res, next) {
    var code = err.status || 500;
    return res.status(code).json({
        error: true,
        code: code,
        data: {message: err.message}
    });
});

var servicesPromises = [];

Promise.all(servicesPromises).then(function() {
  multiLogger.info('app.js','All services initialized');
  server.listen(app.get('port'), function () {
    multiLogger.info('app.js','Express server listening on port ' + app.get('port'));
  });
})
.catch(function(error){
  multiLogger.error('app.js', 'failed to start Feast API:' + JSON.stringify(error));
});







