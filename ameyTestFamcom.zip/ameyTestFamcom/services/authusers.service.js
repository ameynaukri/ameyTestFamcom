var Contact = require('../models/user.model'),
    moment = require('moment'),
    promise = require('bluebird'),
    helperServices = require('../services/helper.service'),
    errorTypes = require('../errortypes');
//var crypto = require("crypto");


exports.addReg = function(params) {
    var username = (params.username) ? params.username : false;
    var password  = (params.password ) ? params.password  : false;
    var full_name  = (params.full_name ) ? params.full_name  : false;
    var contact_no  = (params.contact_no ) ? params.contact_no  : false;
    var Contactdata = new Contact({
        "username": username,
        "password":  password ,
        "full_name":  full_name ,
        "contact_no":  contact_no ,
    });

    return Contactdata.save(null).tap(function(model) {
        Contactdata = model;
        return Contactdata;
    }).then(function(Contactdata) {
        return Contactdata;
    }).catch(function(err) {
        return err;
    });

}

exports.add = function(image_name) {
    console.log("addReg");
    var Contactdata = new Contact({
        "image": image_name,
    });

    return Contactdata.save(null).tap(function(model) {
        Contactdata = model;
        return Contactdata;
    }).then(function(Contactdata) {
        return Contactdata;
    }).catch(function(err) {
        return err;
    });

}

exports.editReg = function(params) {
    //console.log("params ",params)
    var full_name  = (params.full_name ) ? params.full_name  : false;
    var contact_no  = (params.contact_no ) ? params.contact_no  : false;
    var id = (params.user_id) ? params.user_id : false;

    console.log("id ",id)
    params = {
        "full_name": full_name,
        "contact_no": contact_no,
    }
    var updateParams = {
        patch: true
    }
    var data = params;
        return Contact.forge().query(function(qb) {
            qb.where('id', id);
        }).fetchAll().then(function(products) {
            products.forEach(function(products) {
            return products.save(data, updateParams);
        });
    }).catch(function(err) {
        console.log(err);
        return err;
    });

}

exports.UpdateToken = function(token, id) {
    params = {
        "token": token,
    }
    var updateParams = {
        patch: true
    }
    var data = params;
        return Contact.forge().query(function(qb) {
            qb.where('id', id);
        }).fetchAll().then(function(products) {
            products.forEach(function(products) {
            return products.save(data, updateParams);
        });
    }).catch(function(err) {
        console.log(err);
        return err;
    });

}

exports.userExists = function(params){
    console.log(params)
    var username  = (params.username ) ? params.username  : false;
    return Contact.forge().query(function (qb) {
        qb.where({"username":username})
    }).fetch(function(data){
        console.log("data ",data)
        return data;
    }).catch(function(err){
        return err;
    })
}

exports.getNewPassword = function(username,password) {
    params = {
        "password": password,
    }
    var updateParams = {
        patch: true
    }
    var data = params;
        return Contact.forge().query(function(qb) {
            qb.where('username', username);
        }).fetchAll().then(function(products) {
            products.forEach(function(products) {
            return products.save(data, updateParams);
        });
    }).catch(function(err) {
        console.log(err);
        return err;
    });

}


exports.chkAuth = function(params){
    var token  = (params.token ) ? params.token  : false;
    var id = (params.id) ? params.id : false;
    return Contact.forge().query(function (qb) {
        qb.where({"id":id})
        qb.andWhere("token", token);
    }).fetch(function(data){
        console.log("data ",data)
        return data;
    }).catch(function(err){
        return err;
    })
} 

exports.deleteReord = function(id){
    console.log("service delete parking = " + id);
    return Contact.forge().query(function(qp){
        qp.where('id', id);
    }).fetch().then(function(model){
        model.destroy().then(function(data){
            console.log("deleted");
        });
    });
}